/*
  Warnings:

  - The values [CRIAR,EDITAR,EXCLUIR,VISUALIZAR,EXPORTAR,IMPRIMIR] on the enum `TipoAcaoAuditoria` will be removed. If these variants are still used in the database, this will fail.
  - The values [ENTRADA,SAIDA] on the enum `TipoTransacao` will be removed. If these variants are still used in the database, this will fail.
  - You are about to drop the column `endereco` on the `Empresa` table. All the data in the column will be lost.
  - You are about to drop the column `logoUrl` on the `Empresa` table. All the data in the column will be lost.
  - You are about to drop the column `detalhes` on the `LogAuditoria` table. All the data in the column will be lost.
  - You are about to drop the column `entidade` on the `LogAuditoria` table. All the data in the column will be lost.
  - You are about to drop the column `entidadeId` on the `LogAuditoria` table. All the data in the column will be lost.
  - You are about to drop the column `organizacaoId` on the `LogAuditoria` table. All the data in the column will be lost.
  - You are about to drop the column `timestamp` on the `LogAuditoria` table. All the data in the column will be lost.
  - You are about to drop the column `ativo` on the `MembroOrganizacao` table. All the data in the column will be lost.
  - You are about to drop the column `permissoes` on the `MembroOrganizacao` table. All the data in the column will be lost.
  - You are about to drop the column `adminId` on the `Organizacao` table. All the data in the column will be lost.
  - You are about to drop the column `data` on the `TransacaoFinanceira` table. All the data in the column will be lost.
  - You are about to drop the column `fotoPerfil` on the `Usuario` table. All the data in the column will be lost.
  - You are about to drop the column `senhaHash` on the `Usuario` table. All the data in the column will be lost.
  - You are about to drop the column `telefone` on the `Usuario` table. All the data in the column will be lost.
  - You are about to drop the column `ultimoLogin` on the `Usuario` table. All the data in the column will be lost.
  - Made the column `empresaId` on table `LogAuditoria` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `dataVencimento` to the `TransacaoFinanceira` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `TransacaoFinanceira` table without a default value. This is not possible if the table is not empty.
  - Added the required column `empresaId` to the `Usuario` table without a default value. This is not possible if the table is not empty.
  - Added the required column `senha` to the `Usuario` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "public"."StatusTransacao" AS ENUM ('PENDENTE', 'PAGA', 'ATRASADA', 'CANCELADA');

-- AlterEnum
BEGIN;
CREATE TYPE "public"."TipoAcaoAuditoria_new" AS ENUM ('CRIACAO', 'EDICAO', 'EXCLUSAO', 'LOGIN', 'LOGOUT');
ALTER TABLE "public"."LogAuditoria" ALTER COLUMN "acao" TYPE "public"."TipoAcaoAuditoria_new" USING ("acao"::text::"public"."TipoAcaoAuditoria_new");
ALTER TYPE "public"."TipoAcaoAuditoria" RENAME TO "TipoAcaoAuditoria_old";
ALTER TYPE "public"."TipoAcaoAuditoria_new" RENAME TO "TipoAcaoAuditoria";
DROP TYPE "public"."TipoAcaoAuditoria_old";
COMMIT;

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "public"."TipoMovimentacaoEstoque" ADD VALUE 'TRANSFERENCIA';
ALTER TYPE "public"."TipoMovimentacaoEstoque" ADD VALUE 'INVENTARIO';

-- AlterEnum
BEGIN;
CREATE TYPE "public"."TipoTransacao_new" AS ENUM ('RECEITA', 'DESPESA');
ALTER TABLE "public"."TransacaoFinanceira" ALTER COLUMN "tipo" TYPE "public"."TipoTransacao_new" USING ("tipo"::text::"public"."TipoTransacao_new");
ALTER TABLE "public"."ContaPagarReceber" ALTER COLUMN "tipo" TYPE "public"."TipoTransacao_new" USING ("tipo"::text::"public"."TipoTransacao_new");
ALTER TYPE "public"."TipoTransacao" RENAME TO "TipoTransacao_old";
ALTER TYPE "public"."TipoTransacao_new" RENAME TO "TipoTransacao";
DROP TYPE "public"."TipoTransacao_old";
COMMIT;

-- DropForeignKey
ALTER TABLE "public"."LogAuditoria" DROP CONSTRAINT "LogAuditoria_organizacaoId_fkey";

-- DropForeignKey
ALTER TABLE "public"."LogAuditoria" DROP CONSTRAINT "LogAuditoria_usuarioId_fkey";

-- DropForeignKey
ALTER TABLE "public"."Organizacao" DROP CONSTRAINT "Organizacao_adminId_fkey";

-- AlterTable
ALTER TABLE "public"."Empresa" DROP COLUMN "endereco",
DROP COLUMN "logoUrl";

-- AlterTable
ALTER TABLE "public"."LogAuditoria" DROP COLUMN "detalhes",
DROP COLUMN "entidade",
DROP COLUMN "entidadeId",
DROP COLUMN "organizacaoId",
DROP COLUMN "timestamp",
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "dadosAntigos" TEXT,
ADD COLUMN     "dadosNovos" TEXT,
ADD COLUMN     "registroId" TEXT,
ADD COLUMN     "tabela" TEXT,
ALTER COLUMN "empresaId" SET NOT NULL;

-- AlterTable
ALTER TABLE "public"."MembroOrganizacao" DROP COLUMN "ativo",
DROP COLUMN "permissoes",
ALTER COLUMN "role" SET DEFAULT 'VISUALIZADOR';

-- AlterTable
ALTER TABLE "public"."Organizacao" DROP COLUMN "adminId",
ADD COLUMN     "ativa" BOOLEAN NOT NULL DEFAULT true;

-- AlterTable
ALTER TABLE "public"."TransacaoFinanceira" DROP COLUMN "data",
ADD COLUMN     "categoria" TEXT,
ADD COLUMN     "clienteId" TEXT,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "dataPagamento" TIMESTAMP(3),
ADD COLUMN     "dataVencimento" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "observacoes" TEXT,
ADD COLUMN     "status" "public"."StatusTransacao" NOT NULL DEFAULT 'PENDENTE',
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "public"."Usuario" DROP COLUMN "fotoPerfil",
DROP COLUMN "senhaHash",
DROP COLUMN "telefone",
DROP COLUMN "ultimoLogin",
ADD COLUMN     "empresaId" TEXT NOT NULL,
ADD COLUMN     "role" "public"."Role" NOT NULL DEFAULT 'VISUALIZADOR',
ADD COLUMN     "senha" TEXT NOT NULL;

-- AddForeignKey
ALTER TABLE "public"."Usuario" ADD CONSTRAINT "Usuario_empresaId_fkey" FOREIGN KEY ("empresaId") REFERENCES "public"."Empresa"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."TransacaoFinanceira" ADD CONSTRAINT "TransacaoFinanceira_clienteId_fkey" FOREIGN KEY ("clienteId") REFERENCES "public"."Cliente"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."LogAuditoria" ADD CONSTRAINT "LogAuditoria_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "public"."Usuario"("id") ON DELETE CASCADE ON UPDATE CASCADE;
