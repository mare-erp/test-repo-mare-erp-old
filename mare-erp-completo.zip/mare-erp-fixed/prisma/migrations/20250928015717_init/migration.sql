/*
  Warnings:

  - You are about to drop the column `validadeOrcamento` on the `Pedido` table. All the data in the column will be lost.
  - Added the required column `subtotal` to the `ItemPedido` table without a default value. This is not possible if the table is not empty.

*/
-- AlterEnum
ALTER TYPE "public"."StatusPedido" ADD VALUE 'PENDENTE';

-- AlterTable
ALTER TABLE "public"."ItemPedido" ADD COLUMN     "subtotal" DECIMAL(65,30) NOT NULL;

-- AlterTable
ALTER TABLE "public"."Pedido" DROP COLUMN "validadeOrcamento";
